# GUIDE DE CONFIGURATION WIX — ARTÉA GALLERY

> **À quoi sert ce guide ?**
> Le site livré dans `artea-gallery/` est une **démonstration fonctionnelle complète** (maquette interactive haute fidélité) : elle sert de spécification visuelle et fonctionnelle de votre future boutique Wix, et peut aussi servir de prototype à présenter (investisseurs, associés, décorateurs).
> Ce guide explique **étape par étape** comment reproduire chaque élément avec les fonctionnalités **natives de Wix** (Wix Stores, Wix Blog, Wix Forms, Wix Email Marketing), sans coder — et comment configurer ce qui ne peut pas être généré automatiquement (paiements, livraison, taxes, légal).

---

## 0. Prérequis

| Élément | Recommandation |
|---|---|
| Abonnement | Plan **Wix Business / eCommerce** (obligatoire pour Wix Stores) |
| Domaine | À acheter ou connecter (ex. `artea-gallery.com`) — HTTPS est activé automatiquement par Wix |
| Nom de marque | « ARTÉA GALLERY » est **provisoire** : il se remplace partout depuis *Paramètres du site → Marque / Infos de l'entreprise* + en-tête du site (voir §10) |
| Compte bancaire | Nécessaire pour les paiements — voir §4 (point important selon le pays d'enregistrement) |

---

## 1. Structure du site (arborescence à créer)

Dans l'éditeur Wix : **+ Ajouter → Page**, puis renommez et réordonnez le menu.

| Page Wix à créer | URL proposée (SEO) | Équivalent dans la démo |
|---|---|---|
| Accueil | `/` | Page d'accueil (bannière, catégories, sélections, newsletter…) |
| Boutique | `/boutique` | Catalogue avec filtres et tri (natif Wix Stores) |
| Pages produit | auto (`/product-page/…`) → personnaliser en `/oeuvre/{nom}` | Fiche produit détaillée |
| Collections | `/collections/…` | Épure, Horizon, Expression, Héritage, Signature |
| Journal (Wix Blog) | `/journal` | Inspiration & conseils (4 articles fournis) |
| À propos | `/a-propos` | Notre vision |
| Contact (Wix Forms) | `/contact` | Formulaire + coordonnées |
| FAQ | `/faq` | FAQ par catégories |
| Livraison | `/livraison` | Politique de livraison |
| Retours | `/retours` | Politique de retour |
| CGV | `/cgv` | Conditions générales de vente |
| Confidentialité | `/confidentialite` | Politique de confidentialité |
| Mentions légales | `/mentions` | Mentions légales |

**Menu principal :** Accueil · Boutique · Collections · Journal (Inspiration) · À propos · Contact.
**Pied de page :** collections, Livraison, Retours, FAQ, CGV, Confidentialité, Mentions, réseaux sociaux, newsletter, moyens de paiement acceptés (afficher uniquement ceux réellement activés).

**Panier & caisse :** déjà fournis par Wix Stores (*+ Ajouter → Boutique → Panier, Icône panier*). L'icône panier avec compteur s'ajoute dans l'en-tête.

---

## 2. Identité visuelle

Dans l'éditeur : **Style du site → Couleurs et polices → Personnaliser**.

**Palette (à saisir telle quelle) :**

| Rôle | Hex | Usage |
|---|---|---|
| Blanc cassé (fond) | `#FAF7F1` | Arrière-plans principaux |
| Blanc cassé 2 | `#F4EEE3` | Sections alternées |
| Beige sable | `#EDE3D0` | Sections chaleureuses, bandeaux |
| Noir profond | `#171310` | Textes, boutons principaux, pied de page |
| Or discret | `#B08D4F` | Accents, liens, détails |
| Or profond | `#8A6B39` | Sur-titres, survols |

**Typographies (disponibles dans Wix) :**
- Titres : **Playfair Display** (400–600) — grands titres élégants.
- Textes/boutons/menus : **Jost** (300–500) — moderne et lisible.

**Logo :** le monogramme « A » doré de la démo est un placeholder — remplacez-le par votre logo définitif (l'encadré double + monogramme se recrée facilement dans l'éditeur si vous souhaitez le garder provisoirement).
**Favicon :** *Paramètres du site → Favicon*.

---

## 3. Catalogue produits

### 3.1 Créer les collections
**Tableau de bord Wix → Produits → Collections** — créez les 8 catégories **et** les 5 collections :

- Catégories : Tableaux abstraits · Art contemporain · Paysages et nature · Portraits et figures · Art africain et caribéen · Tableaux minimalistes · Art spirituel et symbolique · Décoration murale moderne.
- Collections : **Épure** (minimaliste apaisant) · **Horizon** (paysages) · **Expression** (abstraits colorés) · **Héritage** (africain & caribéen) · **Signature** (premium/éditions limitées).

> La démo n'affiche une catégorie que si des produits existent : faites de même dans Wix (masquez les collections vides de la vitrine jusqu'à leur premier produit).

### 3.2 Créer chaque tableau
**Produits → + Nouveau produit → Produit physique.** Pour chaque œuvre (reprendre `js/data.js`, qui contient tout : noms, descriptions, prix, alt) :

1. **Nom** : ex. « Écho Doré ».
2. **Description** : reprendre les 3 blocs de la démo — *Histoire & inspiration* / *Caractéristiques* / *Conseils déco & espaces recommandés*.
3. **Images** : image principale + vue détail + mise en situation (dès création). **Texte alternatif** : fourni pour chaque œuvre dans `data.js` (champ `alt`) — indispensable pour le SEO.
4. **Options & variantes** (Wix gère nativement jusqu'à 2 options avec variantes, plus avec « options sans variantes ») :
   - Option **Format** : Petit (+0 $) / Moyen (+60 $) / Grand (+120 $) — le prix se règle **par variante** dans le tableau des variantes (la démo additionne : encodez le résultat, ex. Écho Doré petit 189 $ → moyen 249 $ → grand 309 $).
   - Option **Encadrement** : Sans encadrement (+0) / Noir mat (+59) / Chêne naturel (+59) / Blanc (+59).
   - Si vous proposez les 2 supports (Toile / Rigide +45 $), créez les variantes combinées ou ajoutez le support comme option à supplément selon votre plan — sinon facturez le rigide comme produit séparé.
5. **Stock** : « En stock » (préparation 2–3 j) ou « Sur commande » (2–3 semaines) — activez le suivi de stock si les pièces sont uniques.
6. **SEO de la fiche** (*onglet SEO du produit*) : titre = `« {Nom} » — Tableau {catégorie} | ARTÉA GALLERY` ; description = reprendre le `lead` de la démo ; URL = `/oeuvre/{nom-aigu-sans-espaces}`.

### 3.3 Avis clients
Activez **Wix Stores → Avis produits** : ils ne s'afficheront qu'après de vrais avis vérifiés — n'en importez jamais de fictifs. La section « Ils ont choisi ARTÉA » de la démo reste vide tant qu'il n'y a pas d'avis (comportement volontaire et honnête).

---

## 4. Paiements ⚠️ (point critique selon votre pays)

**Constat vérifié (octobre 2026)** : **Wix Payments n'est pas disponible pour une entreprise enregistrée en Haïti**, et PayPal n'y est pas proposé par Wix (liste officielle : *support.wix.com → « Available Payment Providers in Your Country »*). Trois chemins possibles :

**Option A — Paiement manuel (disponible partout, natif Wix)**
*Tableau de bord → Paramètres → Accepter les paiements → Ajouter → Paiement manuel (virement / paiement à la livraison)*. Le client commande en ligne, règle par virement ou à la réception ; vous marquez la commande « payée » à réception. C'est la solution de démarrage la plus simple en Haïti, combinable avec un virement bancaire local (ex. en USD) ou MonCash au niveau manuel.

**Option B — Entité commerciale à l'étranger (recommandé pour la diaspora)**
Si vous créez (ou créez déjà) une entité aux **États-Unis** (ex. LLC + EIN via un service de formation de société), vous pouvez alors activer **Wix Payments (USD)** ou **Stripe/PayPal** dans Wix avec ce pays d'enregistrement. C'est la voie la plus fluide pour encaisser des cartes internationales — faites-vous accompagner pour la fiscalité.

**Option C — Prestataires tiers** : consultez la liste par pays dans l'aide Wix ; la disponibilité change, vérifiez au moment de la configuration.

**Règles :** activez et **testez** chaque moyen avec une vraie petite commande avant la mise en ligne · n'affichez les logos de paiement **qu'après** activation réelle (le pied de page et la caisse de la démo les marquent explicitement « à configurer »).

---

## 5. Livraison et taxes

**Tableau de bord → Paramètres → Livraison et frais** puis **Taxes**.

1. **Zones** (reprendre les zones d'exemple de la démo, à valider avec vos transporteurs) :
   - Haïti — délai 5–7 j ouvrés — 15 $ — + retrait local gratuit sur rendez-vous (activer « Retrait local »).
   - Caraïbes & Amériques — 10–15 j — 45 $.
   - Europe & International — 15–25 j — 75 $.
2. **Surcharge grand format** : créez une règle « par article » supplémentaire (+20 $) appliquée via un **groupe de livraison** : *Produits → groupes de livraison → « Grands formats »* — assignez-y les variantes ≥ 80 cm. C'est exactement le comportement de la démo.
3. **Livraison offerte** dès 250 $ (offre d'exemple à confirmer) : *Livraison → Règles → Livraison gratuite à partir de X*.
4. **Emballage** : prévoir carton double cannelure / caisse, coins mousse, feuille de garde — mentionnez-le sur la page Livraison (texte prêt dans la démo).
5. **Taxes** : configurez selon votre juridiction (en Haïti, l'import/TCA ; si entité US, taxes américaines automatiques via Wix). La démo affiche volontairement « taxes non incluses — à configurer » : remplacez dès que vos taux sont définis.
6. **E-mails d'expédition + suivi** : automatiques dans Wix dès que vous marquez la commande « expédiée » avec numéro de suivi.

---

## 6. E-mails, newsletter et panier abandonné

| Besoin | Où dans Wix |
|---|---|
| Confirmation de commande au client | Automatique (Stores → Paramètres → E-mails) — personnaliser le modèle aux couleurs de la marque |
| Notification vendeur | Automatique (e-mail + app Wix Owner) |
| Panier abandonné | Stores → Marketing & SEO → **Paniers abandonnés** : e-mail de relance automatique (activer après la mise en ligne) |
| Newsletter | **Wix Email Marketing** : formulaire d'inscription (reprendre le libellé de la démo + **case de consentement RGPD obligatoire** : Forms → Consentement), double opt-in recommandé, désinscription en 1 clic (automatique) |
| Formulaire de contact | **Wix Forms** : champs Nom / E-mail / Sujet (liste déroulante : question œuvre, suivi commande, retour, conseil déco, autre) / Message + notifications par e-mail + message de confirmation |

---

## 7. SEO (référencement naturel)

1. **Par page** (*Pages → ⋯ → SEO Google*) : titre + méta-description uniques — reprendre ceux de la démo (champ `title`/`desc` de chaque page) ; activer l'URL lisible.
2. **Slugs proposés** : `/boutique`, `/collections/epure`…, `/oeuvre/echo-dore`, `/journal/choisir-tableau-salon`, `/a-propos`, `/livraison`, `/faq`…
3. **Mots-clés cibles** (à travailler naturellement, sans répétition) : acheter des tableaux décoratifs · tableau mural moderne · tableau pour salon · tableau abstrait contemporain · décoration murale élégante · tableau artistique pour chambre · tableau décoratif premium.
4. **Images** : noms de fichiers propres (déjà faits : `tableau-abstrait-echo-dore.jpg`…) + textes alternatifs (fournis dans `data.js`).
5. **Données structurées produit** : activées nativement par Wix Stores (prix, disponibilité) — la démo en injecte aussi (JSON-LD) pour l'exemple.
6. **Après publication** : *Marketing & SEO → Outils SEO → Sitemap*, puis connecter **Google Search Console** et soumettre le sitemap ; vérifier l'indexation.
7. **Blog** : publier les 4 articles fournis (prêts dans la démo, avec liens vers produits et CTA) puis 1 à 2 articles/mois.
8. **Vitesse** : compresser les photos d'ambiance (< 300 Ko), activer la mise en cache automatique Wix.

---

## 8. Analytics, marketing et cookies

- **Wix Analytics** (natif) : ventes, conversions, sources — tableau de bord → Analytics.
- **Google Analytics 4** et **Meta Pixel** : *Marketing & SEO → Marketing Integrations* — ne les déclarer « connectés » qu'après vérification du flux de données côté Google/Meta.
- **Campagnes e-mail** : Wix Email Marketing (segments : clients, abonnés newsletter).
- **Cookies** : activer la **bannière de consentement Wix** (*Paramètres → Cookies et données personnelles*) avec la politique de confidentialité (texte cadre fourni dans la démo, à faire valider par votre conseil).

---

## 9. Administration au quotidien (sans coder)

| Tâche | Chemin Wix |
|---|---|
| Ajouter un tableau | Produits → + Nouveau produit (§3.2) |
| Modifier un prix | Produits → cliquer l'œuvre → variantes |
| Ajouter des photos | Produit → Images |
| Gérer les stocks | Produits → colonne Stock (alertes de rupture) |
| Créer une promotion | Marketing → **Coupons** (ex. bienvenue 10 % — correspond au code `ART10` de démo) |
| Gérer les commandes | Tableau de bord → Commandes (statuts, remboursements, étiquettes) |
| Rapports de ventes | Analytics → Rapports |
| Publier un article | Blog → + Créer un article |
| Modifier les pages | Éditeur Wix |

---

## 10. Remplacer la marque provisoire & checklist de mise en ligne

**Changer le nom ARTÉA GALLERY :** Éditeur (logo + textes d'en-tête/pied) · *Paramètres du site → Infos du site* (nom affiché) · modèles d'e-mails · réseaux sociaux. Le slogan « Transformez vos murs. Exprimez votre univers. » est également à remplacer si besoin.

**Avant publication, vérifier :**
- [ ] Tous les liens, menus, boutons (y compris mobile)
- [ ] 2–3 commandes de test complètes (avec paiement réel minime, puis remboursement)
- [ ] Filtres/tri boutique, pages produit, variantes et prix par variante
- [ ] E-mails transactionnels reçus (commande, expédition)
- [ ] Mobile : menu, lisibilité, ajout au panier, caisse
- [ ] Pages légales complétées avec vos vraies informations ([À COMPLÉTER] de la démo = endroits à remplir) — **faites valider CGV/retours/confidentialité par votre conseil juridique**
- [ ] Moyens de paiement affichés = moyens réellement actifs
- [ ] Domaine connecté + HTTPS + sitemap soumis
- [ ] Bannière cookies activée
- [ ] Toute mention « démonstration / à configurer » retirée (la démo les affiche volontairement)

---

*Récapitulatif des fichiers livrés :*
- `artea-gallery/` — site de démonstration complet (18 œuvres, 13+ pages, parcours d'achat testé)
- `artea-gallery/js/data.js` — tout le contenu modifiable (produits, prix, textes, SEO, FAQ, articles)
- `artea-gallery/js/app.js` + `js/pages.js` — fonctionnement du site de démonstration
- `GUIDE-CONFIGURATION-WIX.md` — le présent guide
