/* Test de fumée — parcours complet ARTÉA GALLERY (jsdom) */
const { JSDOM, ResourceLoader } = require('jsdom');
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, 'artea-gallery');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8')
  .replace(/<link[^>]*fonts[^>]*>/g, '') // pas de réseau
  .replace(/<script[\s\S]*?<\/script>/g, ''); // scripts injectés manuellement ci-dessous

const wait = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  const dom = new JSDOM(html, {
    url: 'http://localhost:8080/index.html',
    runScripts: 'dangerously',
    pretendToBeVisual: true
  });
  const { window } = dom;
  const { document } = window;
  window.scrollTo = () => {};
  ['js/data.js', 'js/app.js', 'js/pages.js'].forEach(f => {
    window.eval(fs.readFileSync(path.join(root, f), 'utf8'));
  });
  window.eval('App.init()');

  await wait(150);
  const app = document.getElementById('app');

  let failures = 0;
  const check = (label, cond) => {
    console.log((cond ? '  ✓ ' : '  ✗ ') + label);
    if (!cond) failures++;
  };

  console.log('— Accueil');
  check('hero affichée', !!document.querySelector('.hero h1'));
  check('titre accueil', /L'art qui donne vie/.test(document.querySelector('.hero h1').textContent));
  check('catégories visibles', document.querySelectorAll('.cat-card').length === 5);
  check('cartes produits accueil', document.querySelectorAll('.card-product').length >= 6);
  check('avis : état vide honnête', /arrivent bientôt/.test(app.textContent));

  console.log('— Boutique & filtres');
  window.location.hash = '#/boutique';
  await wait(120);
  const count0 = app.querySelectorAll('.card-product').length;
  check('grille remplie', count0 >= 8);
  const catCb = document.querySelector('.filters input[data-k="cats"][data-v="paysages"]');
  catCb.checked = true; catCb.dispatchEvent(new window.Event('change', { bubbles: true }));
  await wait(50);
  const countPaysages = app.querySelectorAll('.card-product').length;
  check('filtre catégorie fonctionne (4 paysages)', countPaysages === 4);
  const sortSel = document.getElementById('shop-sort');
  sortSel.value = 'prix-asc'; sortSel.dispatchEvent(new window.Event('change', { bubbles: true }));
  await wait(30);
  check('tri prix appliqué', /4 œuvres/.test(document.getElementById('shop-count').textContent));

  console.log('— Fiche produit');
  window.location.hash = '#/produit/echo-dore';
  await wait(120);
  check('titre produit', /Écho Doré/.test(document.querySelector('.product-title').textContent));
  const priceBefore = document.getElementById('p-price').textContent;
  const moyBtn = document.querySelector('[data-format="moyen"]');
  moyBtn.dispatchEvent(new window.MouseEvent('click', { bubbles: true }));
  await wait(30);
  const priceAfter = document.getElementById('p-price').textContent;
  check(`variante met à jour le prix (${priceBefore} → ${priceAfter})`, priceBefore !== priceAfter);
  document.getElementById('btn-add').dispatchEvent(new window.MouseEvent('click', { bubbles: true }));
  await wait(30);
  check('badge panier = 1', document.getElementById('cart-count').textContent === '1');
  const rigide = document.querySelector('[data-support="rigide"]');
  rigide.dispatchEvent(new window.MouseEvent('click', { bubbles: true }));
  await wait(30);
  document.getElementById('btn-add').dispatchEvent(new window.MouseEvent('click', { bubbles: true }));
  await wait(30);
  check('badge panier = 2', document.getElementById('cart-count').textContent === '2');
  check('JSON-LD produit injecté', !!document.querySelector('script[data-seo="product"]'));
  check('œuvres similaires', document.querySelectorAll('.card-product').length >= 3);

  console.log('— Œuvre sans support rigide (etreinte)');
  window.location.hash = '#/produit/etreinte';
  await wait(120);
  check('option rigide désactivée', document.querySelector('[data-support="rigide"]').disabled === true);

  console.log('— Panier & code promo');
  window.location.hash = '#/panier';
  await wait(120);
  check('2 lignes panier', document.querySelectorAll('.cart-item').length === 2);
  const inp = document.getElementById('promo-input');
  inp.value = 'ART10';
  document.getElementById('promo-apply').dispatchEvent(new window.MouseEvent('click', { bubbles: true }));
  await wait(60);
  check('promo appliquée', /Code ART10/.test(document.getElementById('app').textContent));
  const zs = document.getElementById('zone-select');
  zs.value = 'international'; zs.dispatchEvent(new window.Event('change', { bubbles: true }));
  await wait(60);
  const txt = document.getElementById('app').textContent;
  check('livraison offerte au-delà de 250 $ (ou frais de zone)', /Offerte|75 \$/.test(txt));

  console.log('— Caisse (démonstration, sans paiement)');
  window.location.hash = '#/commande';
  await wait(120);
  check('mention paiement non activé', /paiement non activé/i.test(app.textContent));
  check('moyens marqués « à configurer »', document.querySelectorAll('[data-]') ? app.textContent.includes('à configurer') : false);
  ['f-prenom|Marie', 'f-nom|Dupont', 'f-email|marie@exemple.com', 'f-addr|12 rue des Arts', 'f-ville|Port-au-Prince'].forEach(pair => {
    const [id, v] = pair.split('|'); document.getElementById(id).value = v;
  });
  document.getElementById('f-pays').value = 'Haïti';
  const pickup = document.querySelector('input[name="ship"][value="pickup"]');
  pickup.checked = true; pickup.dispatchEvent(new window.Event('change', { bubbles: true }));
  await wait(30);
  check('retrait = gratuit dans le récap', /Retrait à l'atelier/.test(document.getElementById('app').textContent));
  document.getElementById('f-cgv').checked = true;
  document.getElementById('co-form').dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true }));
  await wait(150);
  check('page confirmation atteinte', /Merci pour votre commande/.test(app.textContent));
  check('bandeau démonstration visible', /aucun paiement n'a été effectué/i.test(app.textContent));
  check('panier vidé après commande', document.getElementById('cart-count').hidden === true);
  check('référence démo générée', /ART-DEMO-/.test(app.textContent));

  console.log('— Pages éditoriales');
  for (const [hash, re] of [
    ['#/livraison', /Zones desservies/],
    ['#/a-propos', /rendre l'art accessible/i],
    ['#/faq', /Questions fréquentes/],
    ['#/inspiration', /Inspiration et conseils/],
    ['#/article/choisir-tableau-salon', /hauteur d.accroche/i],
    ['#/collections', /cinq atmosphères/i],
    ['#/collection/horizon', /Collection Horizon/],
    ['#/cgv', /Conditions générales/],
    ['#/confidentialite', /confidentialité/i],
    ['#/contact', /Parlons de vos murs/],
    ['#/inexistant', /quitté la galerie/]
  ]) {
    window.location.hash = hash;
    await wait(100);
    check(hash + ' → ' + re, re.test(document.getElementById('app').textContent));
  }

  console.log('— Recherche');
  window.location.hash = '#/';
  await wait(100);
  document.getElementById('open-search').dispatchEvent(new window.MouseEvent('click', { bubbles: true }));
  const si = document.getElementById('search-input');
  si.value = 'or';
  si.dispatchEvent(new window.Event('input', { bubbles: true }));
  await wait(50);
  check('résultats live', document.querySelectorAll('#search-results .card-product').length >= 1);

  console.log(failures === 0 ? '\nTOUS LES TESTS PASSENT ✓' : `\n${failures} ÉCHEC(S) ✗`);
  process.exit(failures === 0 ? 0 : 1);
})().catch(e => { console.error('ERREUR TEST:', e); process.exit(1); });
